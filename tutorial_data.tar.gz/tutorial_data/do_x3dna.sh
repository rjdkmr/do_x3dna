#! /bin/sh


# Environment variable $GMXLIB should be defined


rm *.dat *.xvg *.pdb *.out

echo 1 | do_x3dna -s cdna/cdna.tpr -f cdna/cdna.xtc -noavg -nofit -name cdna -ref
echo 1 | do_x3dna -s odna/odna.tpr -f odna/odna.xtc -noavg -nofit -name odna -ref

